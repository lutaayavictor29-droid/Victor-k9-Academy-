# Victor K9 Academy — Android starter project

This is the first Android UI prototype for Victor K9 Academy.

## Included
- Home screen and academy branding
- Training topic library
- Video library placeholders
- Course detail screens
- Dog profile screen placeholder
- Administrator dashboard visual preview
- Android `FLAG_SECURE` protection enabled on the app window to block Android screenshots and most OS-level screen capture

## Open the project
1. Install Android Studio (a recent stable version).
2. Open this `VictorK9Academy` folder.
3. Allow Gradle sync to download the Android Gradle Plugin and AndroidX dependencies.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press Run.

## Important: prototype, not a finished public service
This project is a front-end starter. It does not yet have:
- Real user registration/login
- A secure owner/admin identity and permissions
- Cloud video uploads or video hosting
- Persistent dog profiles or progress sync
- Real subscriptions or payment processing
- Community moderation or messaging

Those features need a backend and secure server-side access rules. Do not put an administrator password, payment secret, or private API key in the Android app. The administrator preview is deliberately labelled as a preview and is not secure authentication.

## Screen recording protection
`FLAG_SECURE` is enabled in `MainActivity`. Android will block screenshots and most built-in screen recording/casting capture of this app's secure window. No app can guarantee protection against an external camera filming the display or every modified device/OS capture method.

## Brand
Victor K9 Academy  
Tagline: Learn. Train. Understand Your Dog.
