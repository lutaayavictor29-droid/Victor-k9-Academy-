package com.victork9academy

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101B2D)
private val Blue = Color(0xFF2477D4)
private val Pale = Color(0xFFF3F6FA)
private val Ink = Color(0xFF182335)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Protect app windows from Android screenshots and most screen-capture APIs.
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        setContent { VictorK9App() }
    }
}

@Composable
fun VictorK9App() {
    var selected by remember { mutableStateOf("Home") }
    var showAdminPreview by remember { mutableStateOf(false) }
    var selectedCourse by remember { mutableStateOf<String?>(null) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            secondary = Navy,
            background = Pale,
            surface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Pale) {
            Column {
                if (showAdminPreview) {
                    AdminPreview(onBack = { showAdminPreview = false })
                } else if (selectedCourse != null) {
                    CourseDetail(
                        title = selectedCourse!!,
                        onBack = { selectedCourse = null }
                    )
                } else {
                    when (selected) {
                        "Home" -> HomeScreen(
                            onCourse = { selectedCourse = it },
                            onAdmin = { showAdminPreview = true }
                        )
                        "Learn" -> LearnScreen(onCourse = { selectedCourse = it })
                        "Videos" -> VideosScreen()
                        else -> ProfileScreen()
                    }
                    NavigationBar(containerColor = Color.White) {
                        listOf("Home", "Learn", "Videos", "Profile").forEach { item ->
                            NavigationBarItem(
                                selected = selected == item,
                                onClick = { selected = item },
                                icon = { Text(when(item) {
                                    "Home" -> "⌂"
                                    "Learn" -> "▤"
                                    "Videos" -> "▶"
                                    else -> "●"
                                }, fontSize = 20.sp) },
                                label = { Text(item) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Header() {
    Column(
        Modifier.fillMaxWidth().background(Navy).padding(horizontal = 20.dp, vertical = 22.dp)
    ) {
        Text("VICTOR K9 ACADEMY", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
        Text("Learn. Train. Understand Your Dog.", color = Color(0xFFD8E7F8), fontSize = 13.sp)
    }
}

@Composable
fun HomeScreen(onCourse: (String) -> Unit, onAdmin: () -> Unit) {
    LazyColumn(Modifier.weight(1f)) {
        item { Header() }
        item {
            Column(Modifier.padding(18.dp)) {
                Text("Welcome to the academy", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("Build a stronger relationship with your dog through kind, practical training.", color = Color.DarkGray)
                Spacer(Modifier.height(18.dp))
                Box(
                    Modifier.fillMaxWidth().background(Blue, RoundedCornerShape(18.dp)).padding(18.dp)
                ) {
                    Column {
                        Text("START YOUR TRAINING JOURNEY", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.height(6.dp))
                        Text("Small steps. Consistent practice. A happier dog.", color = Color.White, fontSize = 17.sp)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { onCourse("Basic Obedience") }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Navy)) {
                            Text("Start learning")
                        }
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text("Explore training", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                Spacer(Modifier.height(10.dp))
                val topics = listOf(
                    "Puppy Training" to "Start with confidence, routines and socialisation.",
                    "Basic Obedience" to "Teach sit, down, stay, recall and focus.",
                    "Leash Training" to "Enjoy calmer, safer walks together.",
                    "Dog Behaviour" to "Understand barking, jumping and chewing.",
                    "Home Training" to "Build good household and toilet habits.",
                    "Advanced Skills" to "Explore scent games and agility foundations."
                )
                topics.forEach { (title, desc) -> TopicCard(title, desc) { onCourse(title) } }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = onAdmin, modifier = Modifier.fillMaxWidth()) {
                    Text("Administrator dashboard preview")
                }
                Text("Preview only: secure owner sign-in and publishing tools are connected in the production phase.", fontSize = 11.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
fun TopicCard(title: String, desc: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFFE5F0FC), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Text("🐾", fontSize = 21.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, color = Ink)
                Text(desc, fontSize = 12.sp, color = Color.DarkGray)
            }
            Text("›", fontSize = 28.sp, color = Blue)
        }
    }
}

@Composable
fun LearnScreen(onCourse: (String) -> Unit) {
    LazyColumn(Modifier.weight(1f)) {
        item { Header() }
        item {
            Column(Modifier.padding(18.dp)) {
                Text("Training library", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("Choose a topic and work through lessons at your dog's pace.")
                listOf("Puppy Training", "Basic Obedience", "Leash Training", "Dog Behaviour", "Home Training", "Advanced Skills", "Dog Care & Nutrition").forEach {
                    TopicCard(it, "Lessons and guided practice") { onCourse(it) }
                }
            }
        }
    }
}

@Composable
fun VideosScreen() {
    LazyColumn(Modifier.weight(1f)) {
        item { Header() }
        item {
            Column(Modifier.padding(18.dp)) {
                Text("Video library", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("Training demonstrations published by Victor K9 Academy.")
                Spacer(Modifier.height(14.dp))
                listOf("Teaching your dog to sit", "Building a reliable recall", "Loose-leash walking basics").forEach { title ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(16.dp)) {
                            Box(Modifier.fillMaxWidth().height(125.dp).background(Navy, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                                Text("▶", color = Color.White, fontSize = 38.sp)
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(title, fontWeight = FontWeight.Bold)
                            Text("Video placeholder — add your academy video when the content system is connected.", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen() {
    LazyColumn(Modifier.weight(1f)) {
        item { Header() }
        item {
            Column(Modifier.padding(18.dp)) {
                Text("Your learning profile", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("Create a profile to keep your dog's learning journey organised.")
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(value = "", onValueChange = {}, label = { Text("Dog's name") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = "", onValueChange = {}, label = { Text("Breed (optional)") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = "", onValueChange = {}, label = { Text("Age") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                Button(onClick = {}, modifier = Modifier.fillMaxWidth(), enabled = false) { Text("Save profile — account setup coming next") }
                Spacer(Modifier.height(12.dp))
                Text("Sign-in, saved progress and membership status will be enabled when the secure account service is connected.", fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
fun CourseDetail(title: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("‹  Back", color = Color.White, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(18.dp))
            Text("COURSE", color = Color.White, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.padding(20.dp)) {
            Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("A practical learning path from Victor K9 Academy.")
            Spacer(Modifier.height(18.dp))
            listOf(
                "1. Understand the goal",
                "2. Prepare a quiet training space",
                "3. Use rewards your dog enjoys",
                "4. Practise in short, positive sessions",
                "5. Gradually practise around distractions",
                "6. Review progress and keep sessions enjoyable"
            ).forEach { line ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Text(line, Modifier.padding(15.dp), color = Ink)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Safety note: use reward-based methods. Avoid intimidation, pain or punishment. For fear, aggression or sudden behaviour changes, seek help from a qualified humane trainer or veterinarian.", fontSize = 12.sp, color = Color.DarkGray)
        }
    }
}

@Composable
fun AdminPreview(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("‹  Back", color = Color.White, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(18.dp))
            Text("ADMIN DASHBOARD PREVIEW", color = Color.White, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.padding(20.dp)) {
            Text("Academy control centre", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("Owner-only tools planned for Victor's verified administrator account.")
            Spacer(Modifier.height(16.dp))
            listOf("Upload a training video", "Publish an article", "Create a course", "Manage free and premium lessons", "Review members", "Send academy announcements").forEach {
                TopicCard(it, "Administrator feature — production setup required") {}
            }
            Text("This is a visual preview, not a secured admin login. Do not publish content or manage members from this demo screen.", fontSize = 12.sp, color = Color(0xFF9A4B00))
        }
    }
}
